package com.example.zipkinorderservice.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.zipkinorderservice.model.Order;

@RestController
@RequestMapping("/orders")
public class OrderController {

	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping
	public List<Order> getOrders(){
		String productServiceUrl = "http://localhost:8081/products";
		
		List<Map<String, Object>> products = restTemplate.getForObject(productServiceUrl, List.class);
		
		return products.stream()
				.map( p -> new Order(
						Long.valueOf(p.get("id").toString()),
						p.get("name").toString(),
						Double.parseDouble(p.get("price").toString())
						))
						.toList();
	}
}
