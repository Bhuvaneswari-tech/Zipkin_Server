package com.example.zipkinorderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZipkinorderserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
