package com.example.zipkinproductservice.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.zipkinproductservice.model.Product;

@RestController
@RequestMapping("/products")
public class ProductController {
	
	@GetMapping
	public List<Product> getProducts(){
		return List.of(
				new Product(1L, "Laptop", 70000.00),
				new Product(2L, "Phone", 40000.00)
				);
	}
	
	@GetMapping("/{id}")
	public Product getProductById(@PathVariable Long id) {
		return new Product(id, "Sample Product", 500.00);
	}
	
}
