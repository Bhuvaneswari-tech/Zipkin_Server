package com.example.zipkinproductservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZipkinProductServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
